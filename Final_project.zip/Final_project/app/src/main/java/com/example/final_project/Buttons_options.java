package com.example.final_project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class Buttons_options extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buttons_options);

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("BakingAppPrefs", MODE_PRIVATE);

        // Initialize views
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Your existing onCreate code here
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Already on home
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        } else if (id == R.id.nav_cakes) {
            Intent intent = new Intent(this, Cakes.class);
            startActivity(intent);
        } else if (id == R.id.nav_cupcakes) {
            Intent intent = new Intent(this, Cupcakes.class);
            startActivity(intent);
        } else if (id == R.id.nav_cookies) {
            Intent intent = new Intent(this, Cookies.class);
            startActivity(intent);
        } else if (id == R.id.nav_popular) {
            Intent intent = new Intent(this, Popular.class);
            startActivity(intent);
        } else if (id == R.id.nav_profile) {
            // Handle profile navigation
            Toast.makeText(this, "Profile section coming soon!", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_timer) {
            // Handle timer navigation
            Toast.makeText(this, "Timer section coming soon!", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_logout) {
            // Handle logout
            logout();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void logout() {
        // Clear login state
        sharedPreferences.edit()
                .putBoolean("isLoggedIn", false)
                .apply();

        // Navigate to login screen
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    public void onClickCakes(View view) {
        Intent intent = new Intent(this, Cakes.class);
        startActivity(intent);
    }
    public void onClickCupcakes(View view) {
        Intent intent = new Intent(this, Cupcakes.class);
        startActivity(intent);
    }
    public void onClickCookies(View view) {
        Intent intent = new Intent(this, Cookies.class);
        startActivity(intent);
    }
    public void onClickPopular(View view) {
        Intent intent = new Intent(this, Popular.class);
        startActivity(intent);
    }


}